# MongoDB lab

Start a local MongoDB Community Server first. Install `pymongo` with `python -m pip install pymongo`. Implement solution.py and run `python test_solution.py`. Tests create and remove only a randomly named temporary collection under practical_9569_lab. Reference code is in solution/; run tests from that folder to compare.

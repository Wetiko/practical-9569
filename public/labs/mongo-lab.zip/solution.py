def manage(collection):
    # See students.json in the download.
    pass

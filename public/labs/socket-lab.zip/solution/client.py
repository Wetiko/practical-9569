import socket

def request(text):
    with socket.create_connection(('127.0.0.1',5055),timeout=3) as sock:
        sock.sendall((text+'\n').encode('utf-8'))
        data=b''
        while b'\n' not in data:
            chunk=sock.recv(1024)
            if not chunk:raise ConnectionError('Server closed before newline')
            data+=chunk
        return data.split(b'\n',1)[0].decode('utf-8')
if __name__=='__main__': print(request(input('Message: ')))

# Results portal lab

Install Python 3, then from this folder run:

```
python -m pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000. Complete app.py, templates/index.html and static/style.css. Run `python -m unittest test_app.py`. The starter fails until implemented. The complete reference is in solution/. It has the same tests; run them from that folder to compare.

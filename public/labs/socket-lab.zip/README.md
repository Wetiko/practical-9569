# Socket lab

Use two terminals. Complete server.py and client.py. In terminal 1 run `python server.py`; in terminal 2 run `python test_socket.py`. Stop the server with Ctrl+C. No extra packages required. Reference files are in solution/. Use a free local port 5055; if changed, update all three files consistently.

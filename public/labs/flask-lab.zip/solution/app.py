from flask import Flask, request, redirect, render_template
import sqlite3
from pathlib import Path
from uuid import uuid4
from PIL import Image
from flask import send_from_directory
from werkzeug.exceptions import RequestEntityTooLarge
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024
app.config['DATABASE'] = 'results.db'
app.config['UPLOAD_FOLDER'] = 'uploads'

def connect():
    db = sqlite3.connect(app.config['DATABASE'])
    db.execute('CREATE TABLE IF NOT EXISTS Result(name TEXT, score INTEGER)')
    return db

@app.get('/')
def index():
    with connect() as db:
        rows = db.execute('SELECT name, score FROM Result ORDER BY name').fetchall()
    folder = Path(app.config['UPLOAD_FOLDER'])
    images = sorted(p.name for p in folder.glob('*.png')) if folder.exists() else []
    return render_template('index.html', rows=rows, images=images)

@app.post('/add')
def add():
    name = request.form.get('name', '').strip()
    try:
        score = int(request.form.get('score', ''))
    except ValueError:
        return 'Invalid score', 400
    if not name or not 0 <= score <= 100:
        return 'Invalid data', 400
    with connect() as db:
        db.execute('INSERT INTO Result VALUES (?, ?)', (name, score))
    return redirect('/')

@app.post('/upload')
def upload():
    image = request.files.get('image')
    if image is None or not image.filename:
        return 'Missing image', 400
    try:
        img = Image.open(image.stream)
        if img.width * img.height > 4_000_000:
            return 'Image too large', 400
        img.load()
        img = img.convert('RGB')
    except Exception:
        return 'Invalid image', 400
    folder = Path(app.config['UPLOAD_FOLDER'])
    folder.mkdir(exist_ok=True)
    filename = uuid4().hex + '.png'
    img.save(folder / filename, format='PNG')
    return redirect('/')

@app.get('/uploads/<filename>')
def uploaded(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run()

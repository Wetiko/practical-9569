from pymongo import MongoClient
from uuid import uuid4
from solution import manage
client = MongoClient('mongodb://127.0.0.1:27017/', serverSelectionTimeoutMS=3000)
db = client['practical_9569_lab']
name = 'test_' + uuid4().hex
collection = db[name]
try:
    assert manage(collection) == ['Ari','Mei']
    assert collection.count_documents({}) == 2
    assert collection.find_one({'name':'Ari'})['score'] == 81
    assert collection.find_one({'name':'Jo'}) is None
    print('All MongoDB checks passed')
finally:
    db.drop_collection(name)
    client.close()

import unittest, tempfile, io, sqlite3
from pathlib import Path
from PIL import Image
from app import app
class PortalTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        app.config.update(TESTING=True,DATABASE=str(Path(self.tmp.name)/'test.db'),UPLOAD_FOLDER=str(Path(self.tmp.name)/'uploads'))
        self.client=app.test_client()
        self.assertEqual(self.client.get('/').status_code,200)
    def tearDown(self):self.tmp.cleanup()
    def test_valid_persists(self):
        self.assertEqual(self.client.post('/add',data={'name':'Ari','score':'80'}).status_code,302)
        self.assertIn(b'Ari',self.client.get('/').data)
        with sqlite3.connect(app.config['DATABASE']) as db:self.assertEqual(db.execute('SELECT score FROM Result').fetchone()[0],80)
    def test_invalid_no_insert(self):
        for data in [{},{'name':'A','score':'101'},{'name':'A','score':'bad'},{'name':' ','score':'10'},{'name':'A','score':'-1'}]:self.assertEqual(self.client.post('/add',data=data).status_code,400)
        with sqlite3.connect(app.config['DATABASE']) as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM Result').fetchone()[0],0)
    def test_escaped_output(self):
        self.client.post('/add',data={'name':'<script>x</script>','score':'0'})
        data=self.client.get('/').data
        self.assertIn(b'&lt;script&gt;',data)
        self.assertNotIn(b'<script>x</script>',data)
    def test_image(self):
        b=io.BytesIO();Image.new('RGB',(2,2)).save(b,'PNG');b.seek(0)
        response=self.client.post('/upload',data={'image':(b,'../../outside.png')})
        self.assertEqual(response.status_code,302)
        files=list(Path(app.config['UPLOAD_FOLDER']).glob('*.png'))
        self.assertEqual(len(files),1)
        self.assertIn(files[0].name.encode(),self.client.get('/').data)
        self.assertEqual(self.client.get('/uploads/'+files[0].name).status_code,200)
    def test_bad_image(self):
        self.assertEqual(self.client.post('/upload',data={'image':(io.BytesIO(b'not an image'),'fake.png')}).status_code,400)
if __name__=='__main__':unittest.main()

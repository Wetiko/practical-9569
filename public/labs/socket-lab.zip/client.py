def request(text):
    # Connect, send a newline-terminated message, and return the reply.
    pass

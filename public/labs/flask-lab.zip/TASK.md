# Build the results portal

Build a Flask application that lists student results from SQLite at GET /. At POST /add, validate a non-empty name and an integer score from 0–100, insert with parameters, and redirect to /. Invalid data must return HTTP 400 without inserting. Display results in an HTML table with labels and readable CSS. Extend it with an image upload saved under a generated safe filename and display the image. Download the local lab to run Flask on your computer. This lab is self-assessed; browser Python cannot host a Flask server.

## Acceptance checklist
- GET / renders a table with persisted records.
- POST /add saves valid input and redirects.
- Invalid, missing, and out-of-range values return 400 without insertion.
- SQL uses parameters; template output is escaped.
- Form controls have labels and the table has headings.
- Image upload validates content and uses a generated filename.
- An uploaded image is displayed; records persist after restarting.

Reference answers are in solution/. Attempt the task before opening them.

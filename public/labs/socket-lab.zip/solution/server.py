# server.py
import socket
with socket.socket() as server:
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('127.0.0.1', 5055))
    server.listen()
    while True:
        connection, address = server.accept()
        with connection:
            data = b''
            while b'\n' not in data:
                chunk = connection.recv(1024)
                if not chunk:
                    break
                data += chunk
            if b'\n' in data:
                line = data.split(b'\n', 1)[0].decode('utf-8')
                connection.sendall((line.upper() + '\n').encode('utf-8'))

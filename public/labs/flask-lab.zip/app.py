from flask import Flask, request, redirect, render_template
import sqlite3

app = Flask(__name__)

# Implement routes and templates in the downloaded lab.

if __name__ == "__main__":
    app.run()

# Manage a document collection

Using PyMongo and a local MongoDB server, write manage(collection) that inserts the supplied students, updates Ari’s score to 81, removes records with scores below 50, and returns names with scores >= 80 sorted alphabetically. Use the supplied practice-only collection. Download the lab for fixtures, runnable checks and a reference solution. This requires MongoDB on your computer.

## Acceptance checklist
- Connect to a local practice MongoDB database.
- Insert the three supplied documents.
- Update Ari to 81 with $set.
- Delete scores below 50.
- Return ["Ari", "Mei"] in sorted order.
- Pass the downloaded checks against a fresh collection.

Reference answers are in solution/. Attempt the task before opening them.

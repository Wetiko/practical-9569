def manage(collection):
    collection.insert_many([
        {'name':'Ari','score':78},
        {'name':'Mei','score':92},
        {'name':'Jo','score':45}])
    collection.update_one({'name':'Ari'}, {'$set':{'score':81}})
    collection.delete_many({'score':{'$lt':50}})
    return [doc['name'] for doc in collection.find(
        {'score':{'$gte':80}}, {'_id':0,'name':1}).sort('name',1)]

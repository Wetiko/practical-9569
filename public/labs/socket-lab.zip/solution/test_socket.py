import socket
from client import request
assert request('hello')=='HELLO'
assert request('again')=='AGAIN'
assert request('')==''
with socket.create_connection(('127.0.0.1',5055),timeout=3) as s:
    s.sendall(b'par');s.sendall(b'tial\n')
    data=b''
    while b'\n' not in data:data+=s.recv(1024)
    assert data==b'PARTIAL\n'
print('All socket checks passed')

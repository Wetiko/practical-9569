# The line-based echo service

Implement a TCP client and iterative server on 127.0.0.1:5055. Each connection sends one UTF-8 line terminated by newline; the server responds with the uppercase line plus newline, then closes the connection. The server must accept the next client. Handle data split across recv() calls. Download the lab to run sockets locally. Browser Python cannot create raw TCP connections.

## Acceptance checklist
- Bind only to 127.0.0.1:5055 for this exercise.
- Read until newline across multiple recv calls.
- Respond in uppercase with a final newline.
- Use sendall and UTF-8 encoding.
- Close each accepted connection.
- Serve a second client without restarting the server.

Reference answers are in solution/. Attempt the task before opening them.
